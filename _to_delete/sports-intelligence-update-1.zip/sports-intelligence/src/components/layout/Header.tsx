import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import { SportSwitcher } from "./SportSwitcher";
import { LanguageSwitcher } from "./LanguageSwitcher";

export function Header() {
  const t = useTranslations("meta");
  const tNav = useTranslations("nav");

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[var(--background)]/90 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2 text-white">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-400 to-violet-500 text-sm font-bold text-slate-950">
            SI
          </span>
          <span className="text-base font-semibold tracking-tight sm:text-lg">{t("siteName")}</span>
        </Link>

        <div className="flex shrink-0 items-center gap-2">
          <LanguageSwitcher />
          <Link
            href="/search"
            aria-label={tNav("search")}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/5 text-slate-300 transition-colors hover:bg-white/10 hover:text-white"
          >
            <svg
              className="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              aria-hidden
            >
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.5-3.5" strokeLinecap="round" />
            </svg>
          </Link>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-4 pb-3 sm:px-6">
        <SportSwitcher />
      </div>
    </header>
  );
}
