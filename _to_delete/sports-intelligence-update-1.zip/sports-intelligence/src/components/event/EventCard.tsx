import { useLocale, useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { SportEvent } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { StatusPill } from "@/components/ui/StatusPill";
import { Badge } from "@/components/ui/Badge";
import { Countdown } from "@/components/ui/Countdown";
import { LocalDateTime } from "@/components/ui/LocalDateTime";

export function EventCard({ event, compact = false }: { event: SportEvent; compact?: boolean }) {
  const locale = useLocale();
  const tSport = useTranslations("sportPage");
  const showScore = event.status === "finished";

  return (
    <Link href={`/${event.sport}/match/${event.slug}`}>
      <Card hoverable className="flex h-full flex-col gap-3 p-4">
        <div className="flex items-center justify-between gap-2">
          <span className="truncate text-xs font-medium text-[var(--muted)]">
            {event.competition.name}
          </span>
          <StatusPill status={event.status} />
        </div>

        <div className="flex flex-1 flex-col gap-2">
          <TeamRow name={event.home.team.name} short={event.home.team.shortName} score={showScore ? event.home.score : undefined} />
          <TeamRow name={event.away.team.name} short={event.away.team.shortName} score={showScore ? event.away.score : undefined} />
        </div>

        {event.status === "scheduled" && (
          <div>
            <Countdown startTime={event.startTime} />
          </div>
        )}

        {!compact && (
          <div className="flex items-center justify-between border-t border-white/10 pt-3 text-xs text-[var(--muted)]">
            <LocalDateTime iso={event.startTime} locale={locale} mode="eventDateTime" />
            <div className="flex gap-1.5">
              {event.hasPrediction && <Badge tone="accent">{tSport("predictions")}</Badge>}
              {event.hasIntelligence && <Badge tone="warning">AI</Badge>}
            </div>
          </div>
        )}
      </Card>
    </Link>
  );
}

function TeamRow({ name, short, score }: { name: string; short: string; score?: number }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <span className="flex items-center gap-2 truncate text-sm font-medium text-white">
        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-white/10 text-[10px] font-semibold text-slate-200">
          {short.slice(0, 2)}
        </span>
        <span className="truncate">{name}</span>
      </span>
      {score !== undefined && <span className="text-sm font-semibold text-white">{score}</span>}
    </div>
  );
}
