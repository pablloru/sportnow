import { useTranslations } from "next-intl";
import { Link } from "@/i18n/navigation";
import type { Sport } from "@/lib/types";
import { Card } from "@/components/ui/Card";

export function SportCategoryGrid({ sports }: { sports: Sport[] }) {
  const t = useTranslations("sports");

  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
      {sports.map((sport) => (
        <Link key={sport.slug} href={`/${sport.slug}`}>
          <Card
            hoverable
            className="flex flex-col items-center justify-center gap-2 p-5 text-center"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-cyan-400/20 to-violet-500/20 text-sm font-bold text-white">
              {t(`${sport.slug}.shortName`).slice(0, 2).toUpperCase()}
            </span>
            <span className="text-sm font-medium text-white">{t(`${sport.slug}.shortName`)}</span>
          </Card>
        </Link>
      ))}
    </div>
  );
}
