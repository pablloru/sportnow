import { useLocale, useTranslations } from "next-intl";
import Image from "next/image";
import type { News } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { LocalDateTime } from "@/components/ui/LocalDateTime";

/** News items don't have their own detail page in V1 (only Sport,
 * Event and Article pages are required by the brief) — this renders
 * as a feed card only. Once a News detail page exists, wrap this in a
 * <Link> the same way EventCard/ArticleCard do. */
export function NewsCard({ news, sport }: { news: News; sport?: string }) {
  const locale = useLocale();
  const t = useTranslations("sports");

  return (
    <Card hoverable className="flex h-full flex-col overflow-hidden">
      {news.image && (
        <div className="relative h-36 w-full overflow-hidden bg-white/5">
          <Image
            src={news.image}
            alt={news.title}
            fill
            sizes="(min-width: 1024px) 320px, 100vw"
            className="object-cover"
          />
        </div>
      )}
      <div className="flex flex-1 flex-col gap-2 p-4">
        <span className="text-xs font-medium uppercase tracking-wide text-[var(--accent)]">
          {t(`${sport ?? news.sport}.shortName`)}
        </span>
        <h3 className="line-clamp-2 text-sm font-semibold leading-snug text-white">{news.title}</h3>
        <p className="line-clamp-2 flex-1 text-sm text-[var(--muted)]">{news.excerpt}</p>
        <div className="flex items-center justify-between pt-1 text-xs text-[var(--muted)]">
          <span>{news.source.name}</span>
          <LocalDateTime iso={news.publishedAt} locale={locale} mode="eventDateTime" />
        </div>
      </div>
    </Card>
  );
}
