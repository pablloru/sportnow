import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { isSportSlug } from "@/lib/constants";
import { teamRepository } from "@/lib/repositories/team.repository";
import { TEAMS } from "@/lib/mock-data";
import { routing, type AppLocale } from "@/i18n/routing";
import { localeAlternates } from "@/lib/seo";
import { tallyForm } from "@/lib/team-comparison";
import { Card } from "@/components/ui/Card";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { FormStrip } from "@/components/event/FormStrip";
import { EventCard } from "@/components/event/EventCard";
import { NewsCard } from "@/components/home/NewsCard";
import { RosterGrid } from "@/components/team/RosterGrid";
import { BackLink } from "@/components/ui/BackLink";

type Props = { params: Promise<{ locale: string; sport: string; slug: string }> };

export function generateStaticParams() {
  return routing.locales.flatMap((locale) =>
    TEAMS.map((team) => ({ locale, sport: team.sport, slug: team.slug }))
  );
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { locale, sport, slug } = await params;
  if (!isSportSlug(sport)) return {};
  const team = await teamRepository.getBySlug(sport, slug);
  if (!team) return {};

  const tSports = await getTranslations({ locale, namespace: "sports" });
  const tTeamPage = await getTranslations({ locale, namespace: "teamPage" });
  const title = team.name;
  const description = tTeamPage("metaDescription", { name: team.name, sport: tSports(`${sport}.name`) });

  return {
    title,
    description,
    alternates: {
      canonical: `/${locale}/${sport}/team/${slug}`,
      languages: localeAlternates((l) => `/${l}/${sport}/team/${slug}`),
    },
    openGraph: { title, description, type: "profile" },
  };
}

export default async function TeamPage({ params }: Props) {
  const { locale, sport, slug } = await params;
  setRequestLocale(locale);
  if (!isSportSlug(sport)) notFound();

  const team = await teamRepository.getBySlug(sport, slug);
  if (!team) notFound();

  const [t, tSport, tCommon, tComparison, roster, events, news] = await Promise.all([
    getTranslations("teamPage"),
    getTranslations("sportPage"),
    getTranslations("common"),
    getTranslations("comparison"),
    teamRepository.getRoster(team.id),
    teamRepository.getEvents(team.id),
    teamRepository.getNews(team.id, 6, locale as AppLocale),
  ]);

  const upcoming = events
    .filter((e) => e.status === "scheduled")
    .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime())
    .slice(0, 6);
  const finished = events.filter((e) => e.status === "finished").slice(0, 6);

  const tally = tallyForm(team.form);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "SportsTeam",
    name: team.name,
    sport: sport,
  };

  return (
    <div className="mx-auto max-w-6xl space-y-10 px-4 py-10 sm:px-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <BackLink href={`/${sport}`} label={tCommon("backToSport")} />

      <Card className="p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-white sm:text-3xl">{team.name}</h1>
            {team.country && <p className="mt-1 text-sm text-[var(--muted)]">{team.country}</p>}
          </div>
          {team.form && team.form.length > 0 && (
            <div className="text-right">
              <FormStrip form={team.form} />
              <p className="mt-1.5 text-xs text-[var(--muted)]">
                {tally.wins}
                {tComparison("winsShort")}-{tally.draws}
                {tComparison("drawsShort")}-{tally.losses}
                {tComparison("lossesShort")}
              </p>
            </div>
          )}
        </div>
      </Card>

      {upcoming.length > 0 && (
        <section>
          <SectionHeading title={tSport("upcoming")} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>
      )}

      {finished.length > 0 && (
        <section>
          <SectionHeading title={tSport("results")} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {finished.map((event) => (
              <EventCard key={event.id} event={event} />
            ))}
          </div>
        </section>
      )}

      {roster.length > 0 && (
        <section>
          <SectionHeading title={t("roster")} />
          <RosterGrid players={roster} sport={sport} />
        </section>
      )}

      {news.length > 0 && (
        <section>
          <SectionHeading title={tSport("news")} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {news.map((item) => (
              <NewsCard key={item.id} news={item} sport={sport} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
