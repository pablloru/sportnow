import type { Metadata } from "next";
import { getTranslations, setRequestLocale } from "next-intl/server";
import { getHomePageData } from "@/lib/services/home.service";
import { localeAlternates } from "@/lib/seo";
import type { AppLocale } from "@/i18n/routing";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { SportCategoryGrid } from "@/components/home/SportCategoryGrid";
import { EventCard } from "@/components/event/EventCard";
import { NewsCard } from "@/components/home/NewsCard";
import { PredictionMiniCard } from "@/components/home/PredictionMiniCard";
import { TodayInsights } from "@/components/home/TodayInsights";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ locale: string }>;
}): Promise<Metadata> {
  const { locale } = await params;
  const t = await getTranslations({ locale, namespace: "meta" });
  return {
    title: t("defaultTitle"),
    description: t("defaultDescription"),
    alternates: { canonical: `/${locale}`, languages: localeAlternates((l) => `/${l}`) },
  };
}

export default async function HomePage({
  params,
}: {
  params: Promise<{ locale: string }>;
}) {
  const { locale } = await params;
  setRequestLocale(locale);

  const t = await getTranslations("home");
  const { sports, upcoming, popular, latestNews, predictions, todayInsights } =
    await getHomePageData(locale as AppLocale);

  return (
    <div className="mx-auto max-w-7xl space-y-14 px-4 py-10 sm:px-6">
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 p-8 sm:p-12">
        <div
          className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-cyan-500/20 blur-3xl"
          aria-hidden
        />
        <div
          className="pointer-events-none absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-violet-500/20 blur-3xl"
          aria-hidden
        />
        <div className="relative max-w-2xl">
          <h1 className="text-3xl font-bold tracking-tight text-white sm:text-4xl">
            {t("heroTitle")}
          </h1>
          <p className="mt-3 text-base text-[var(--muted)] sm:text-lg">{t("heroSubtitle")}</p>
        </div>
      </section>

      <section>
        <SectionHeading title={t("sectionCategories")} />
        <SportCategoryGrid sports={sports} />
      </section>

      {todayInsights.length > 0 && (
        <section>
          <SectionHeading title={t("sectionToday")} />
          <TodayInsights insights={todayInsights} />
        </section>
      )}

      <section>
        <SectionHeading title={t("sectionUpcoming")} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {upcoming.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>
      </section>

      {popular.length > 0 && (
        <section>
          <SectionHeading title={t("sectionPopular")} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {popular.map((event) => (
              <EventCard key={event.id} event={event} compact />
            ))}
          </div>
        </section>
      )}

      {predictions.length > 0 && (
        <section>
          <SectionHeading title={t("sectionPredictions")} />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {predictions.map(
              ({ event, prediction }) =>
                prediction && <PredictionMiniCard key={event.id} event={event} prediction={prediction} />
            )}
          </div>
        </section>
      )}

      <section>
        <SectionHeading title={t("sectionNews")} />
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {latestNews.map((news) => (
            <NewsCard key={news.id} news={news} />
          ))}
        </div>
      </section>
    </div>
  );
}
